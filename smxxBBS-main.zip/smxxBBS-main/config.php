
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style>
body {width: 56rem; max-width: 96%; margin: auto; background: #eef2ff; color: #000; font-family: arial,helvetica,sans-serif; font-size: 0.9em;}
h1 {color: #af0a0f; margin-bottom: 0.1em;}
hr {border: 1px solid #b7c5d9;}
a {color: #34345c; text-decoration: underline;}
a:hover { color: #fb4934; text-decoration: bold; }
.newpost table, th, td { background: #98e; border: 1px #000 solid; padding: 2px; text-align: left; font-weight: bold;}
div.post {background-color: #d6daf0; padding: 0.25em 1em 0.25em 1em; margin-top: 0.25em; margin-bottom: 0.25em; border: 1px solid #b7c5d9;}
.deleted { text-align: left; color: #800000; font-size: 12pt; font-weight: bold;}
.info { color: #0f0c5d; font-size: 12pt; }
.poster { padding: 0 5px; border-radius: 3px; text-shadow: 2px 2px #000000; color:#FFFFFF}
</style></head>
<?php
$setting_board_name = '2am';			# Name of this textboard
$setting_board_title = "<h1> Testing Board</h1>";	# In-line HTML that shows on top of the board
$setting_admin_pass = 'a333';	 		# Admin pass (CHANGE THIS)
$setting_admin_key = 'ff5g95jg95nt5dw';			# Encryption key for sensitive data (CHANGE THIS)
$setting_time_zone = 'America/New_York';	# Time zone
$setting_board_flow = '1';					# 0 = Oldest posts on top, read top to bottom - 1 = Newest posts on top, read bottom to top
$setting_usercodes = '0'; 					# Allow users to register their names per IP address
$setting_maxchar = '2000';					# Maximum post length permitted
$setting_minchar = '1';					# Minimum post length permitted
$setting_post_wait = '6';					# Seconds a poster must wait before posting again
$setting_wrong_penalty = '6';				# Seconds a poster must wait after getting math wrong
$setting_deleted_msg = "<span class=deleted>THIS POST WAS DELETED.</span>";
$setting_static_div = "cag"; 				# Name of the CSS div for static content (never moves or changes)
$setting_footer_content = "</div><br><br><br><a href='./'>[Home]</a> <br><br><br>";
?>
