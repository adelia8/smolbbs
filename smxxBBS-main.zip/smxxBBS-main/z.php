<?php


echo "<form action='admin.php' method='post'>
<input required type='password' name='adminpass' maxlength='32'><input type='submit' value='Admin'> 
</form>";
?>